<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'a2200704fdfba89e778962238869911e6e80e44964d7c5c7' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'e1&lM7/98MCP-zd>ar&KREA$.9p*CN;[`=4N!_(oI]X@G?fI~Qy KeQp}n9_PIYV' );
define( 'SECURE_AUTH_KEY',  'n8NPF!~>- Grt);&9>3KC_uZ^vrtdT3FGIt yK<#y2ZuBJ<?W2N1#X@A)su=^OO.' );
define( 'LOGGED_IN_KEY',    'UFkITc:Bj?Io~x]0-p>tXVh.AkR|_{|d|5<F*E=xNQ.=*tBvh(:I}C&A#jQdCp#[' );
define( 'NONCE_KEY',        'Usq^68z(T!EaD5xc`Jc%eXf*O- N4bCEi<kEp/AS_=p3.sz}{6r2a;raukqbDFZr' );
define( 'AUTH_SALT',        ',r1& [hM3z:S,+jR#Wofb1F$#g!1%xxrtM&PBN9/}bH0N1?`NFO{&~I2S>:@2!{<' );
define( 'SECURE_AUTH_SALT', 'j-I:utU9@k N#q}!G$ #;6xH^0}7}n9<%RktCo@qCAmL4,f42I!0{ySOM*L/PGIa' );
define( 'LOGGED_IN_SALT',   'khZ7-nbvR_-UWzMe,1Ma,LNxsY!k$KW&Oi>or2?GqBhbQOHVU*sy[u~EWa`^*JN%' );
define( 'NONCE_SALT',       '$-(*5M>2I>h83cvJ%Q]hX@S!L1ydTz*+2/C}@zhDdfx5rZCPa($J<dvm[> t36?H' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
